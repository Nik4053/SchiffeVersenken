import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Scanner;
import client.CLIENT;
import server.SERVER;

public class LOBBY {

	private CLIENT client = new CLIENT();
	private SERVER server = null;
	boolean gameRunning = false;

    /**
     * Hauptprogramm zum Erzeugen des Serverobjekts
     * @param args keine Parameter beim Programmaufruf erforderlich
     */
    public static void main(String[] args)throws UnknownHostException, IOException, InterruptedException {

        Scanner reader = new Scanner(System.in); // Reading from System.in
		System.out.println("Enter 0 to start a new server or 1 to connect to an existing one: ");
		int n = reader.nextInt();
		//reader.close();
		LOBBY lobby = new LOBBY();
		if(n==0){
		   lobby.createServer(6000);
		  }else{
		  lobby.joinServer(6000);
		  }
		  
    }

	public void createServer(int port)throws UnknownHostException, IOException, InterruptedException{
		System.out.println("0");    
		gameRunning = true;
		Runnable gameState = new Runnable() {

			@Override
			public void run() {
			    try {
					server = new SERVER(port);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				while (gameRunning) {
					if (client.GameEnded()) {
						server.endGame();
					}
				}

			}
		};
		Thread gameThread = new Thread(gameState);
		System.out.println("Creating Server...");
		gameThread.start();
		System.out.println("Server created...");
		Thread.sleep(3000);
		client.connect(port);		
		gameRunning = false;
	}

	public void joinServer(int port) throws UnknownHostException, IOException {
		client.connect(port);
	}

}


package server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SERVER {

	/**
	 * L�ist contianign all client5s
	 */
	private Socket[] clients = new Socket[2];
	private ServerSocket serverSocket;
	private int currentPlayerId;
	private boolean gameEnded = false;

	public SERVER(int port) throws IOException {
		serverSocket = new ServerSocket(port);
		// Host wird accepted	
		clients[0] = serverSocket.accept();
		System.out.println("first client connected");
		// waits for opponent	
		clients[1] = serverSocket.accept();
		System.out.println("second client connected");
		this.currentPlayerId = 0;
		clients[0].setSoTimeout(20000);
		clients[1].setSoTimeout(20000);
		startGame();
	}

	public int getPort() {
		return serverSocket.getLocalPort();
	}

	public void startGame() throws IOException {
		//writes to the clients who is first and who is second
		clients[currentPlayerId].getOutputStream().write(1);
		clients[1-currentPlayerId].getOutputStream().write(2);
		while (gameEnded == false) {
			makeTurn();
			if (currentPlayerId == 0) {
				currentPlayerId = 1;
			} else {
				currentPlayerId = 0;
			}
		}
	}

	public void endGame() {
		gameEnded = true;
	}

	/**
	 * Returns the id of the player that has to make its move now
	 * 
	 * @return
	 */
	public int getCurrentPlayer() {
		return currentPlayerId;
	}

	public void makeTurn() throws IOException {
		int otherPlayerId = 0;
				if (currentPlayerId == 0) {
			otherPlayerId = 1;
		} else {
			otherPlayerId = 0;
		}
		OutputStream outputStream1 = clients[currentPlayerId].getOutputStream();
		OutputStream outputStream2 = clients[otherPlayerId].getOutputStream();
		InputStream inputStream1 = clients[currentPlayerId].getInputStream();
		InputStream inputStream2 = clients[otherPlayerId].getInputStream();		
		int x = inputStream1.read();
		int y = inputStream1.read();
		

		
		//sends data to other player
		outputStream2.write(x);
		outputStream2.write(y);
		//gets 1 for hit and 0 for water
		int hit = inputStream2.read();
		outputStream1.write(hit);
	}

}
